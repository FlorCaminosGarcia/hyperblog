__pycache__
/cache
/history/*/*
!/history/*/history.config
!/history/*/olive_config.json
