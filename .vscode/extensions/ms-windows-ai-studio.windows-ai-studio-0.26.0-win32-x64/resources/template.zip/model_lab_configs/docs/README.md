See [Convert a model with AI Toolkit for VS Code](https://code.visualstudio.com/docs/intelligentapps/modelconversion).

Also see https://github.com/microsoft/olive-recipes/tree/main/.aitk/docs
