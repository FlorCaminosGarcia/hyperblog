The evaluator.json provided here is minimized to fit the sanitize.

The main purpose is to provide the UX.
