"""
Sanitize module for Windows AI Studio model configurations
"""
